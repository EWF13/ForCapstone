/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question1;

import java.math.BigInteger;

/****************************************************************************************************
* Project: COMP2080_ASSIGN1_Yogarasa_Ihsaan
* Assignment: ASSIGNMENT #1
* Author(s): Ihsaan Yogarasa 100947868
* Student Number: 100947868
* Date: March 22, 2018
* Description: Test the timing
****************************************************************************************************/
public class TestTiming {
    
    private static int [] testArray; 
    private static Timing t1 = new Timing();
    private static Stopwatch s1 = new Stopwatch();
    
     public static void main(String []args){
    
         System.out.println("TESTING DAFFY FUNCTION \n");
         daffytester();
         System.out.println();
         
         System.out.println("TESTING DONALD FUNCTION \n");
         donaldtester();
         System.out.println();
         
         System.out.println("TESTING MICKEY FUNCTION \n");
         mickeytester();
         System.out.println();
         
         System.out.println("TESTING MINNIE FUNCTION \n");
         minnietester();
         System.out.println();
         
         System.out.println("TESTING GOOFY FUNCTION \n");
         goofytester();
         System.out.println();
      
         System.out.println("TESTING PLUTO FUNCTION \n");
         plutotester();
         System.out.println();
         
         System.out.println("TESTING GYRO FUNCTION \n");
         gyrotester();
         System.out.println();
      
         System.out.println("TESTING FACT FUNCTION \n");
         facttester();
         System.out.println();
         
         
         
    }
    //Code to test Daffy timer 
    public static void daffytester(){
    
        for(int i=30; i<=44; i++ )
        {
            s1.start();
            t1.daffy(i);
            s1.stop();
            System.out.println(" Testing Daffy for " + i + " had an " + s1.toString());
        }
    }
    //Code to test Donald timer
    public static void donaldtester(){
    
        for(int i=30; i<=44; i++ )
        {
            s1.start();
            t1.donald(i);
            s1.stop();
            System.out.println(" Testing Donald for " + i + "  had an " + s1.toString());
        }
    }
    
    //Code to test Mickey timer   
    public static void mickeytester(){
    
        for(int i=1000; i<=8192000; i*=2 )
        {
            testArray = t1.randomarr(i);
            s1.start();
            t1.mickey(testArray);
            s1.stop();
            System.out.println(" Testing Mickey for " + i + "  had an " + s1.toString());
        }
    }
    
    //Code to test Minnie timer
    public static void minnietester(){
    
        for(int i=1000; i<=256000; i*=2 )
        {
            testArray = t1.randomarr(i);
            s1.start();
            t1.minnie(testArray);
            s1.stop();
            System.out.println(" Testing Minnie for " + i + "  had an " + s1.toString());
        }
    }
     
    //Code to test Goofy timer
    public static void goofytester(){
    
        for(int i=1000; i<=256000; i*=2 )
        {
            testArray = t1.randomarr(i);
            s1.start();
            t1.goofy(testArray);
            s1.stop();
            System.out.println(" Testing Goofy for " + i + "  had an " + s1.toString());
        }
    }
       
    //Code to test pluto timer
    public static void plutotester(){
    
        for(int i=1000; i<=256000; i*=2 )
        {
            testArray = t1.randomarr(i);
            s1.start();
            t1.pluto(testArray);
            s1.stop();
            System.out.println(" Testing Pluto for " + i + "  had an " + s1.toString());
        }
    }
    //Code to test gyro timer
    public static void gyrotester(){
    
        for(int i=1000; i<=256000; i*=2 )
        {
            testArray = t1.randomarr(i);
            s1.start();
            t1.gyro(testArray);
            s1.stop();
           // t1.pluto(t1.gyro());
            System.out.println(" Testing Gyro for " + i + "  had an " + s1.toString());
        }
    }
    //Code to test fact timer
    public static void facttester(){
        BigInteger twice = new BigInteger("2");
        BigInteger bi = BigInteger.valueOf((long)1000);
        
        
       for(int i=0; i<7; i++)
       { 
           s1.start();
           t1.fact(bi);
           s1.stop();
           System.out.println(" Testing Fact for " + bi + "  had an " + s1.toString());
           bi = bi.multiply(twice);
            
       }
    }
}
