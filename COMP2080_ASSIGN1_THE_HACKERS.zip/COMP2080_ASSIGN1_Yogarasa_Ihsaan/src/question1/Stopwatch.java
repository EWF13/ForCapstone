/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question1;

/****************************************************************************************************
* Project: COMP2080_ASSIGN1_Yogarasa_Ihsaan
* Assignment: ASSIGNMENT #1
* Author(s): Ihsaan Yogarasa 100947868
* Student Number: 100947868
* Date: March 22, 2018
* Description: Pre-made class to test timing
****************************************************************************************************/
 

public class Stopwatch
{
    private long startTime;
    private long stopTime;

    public static final double NANOS_PER_SEC = 1000000000.0;

	/**
	 starts the stop watch.
	*/
	public void start()
	{	System.gc();
		startTime = System.nanoTime();
	}

	/**
	 stops the stop watch.
	*/
	public void stop()
	{	stopTime = System.nanoTime();	}

	/**
	elapsed time in seconds.
	@return the time recorded on the stop watch in seconds
	*/
	public double time()
	{	return (stopTime - startTime) / NANOS_PER_SEC;	}

	public String toString()
	{   return "elapsed time: " + time() + " seconds.";
	}

	/**
	elapsed time in nanoseconds.
	@return the time recorded on the stop watch in nano-seconds
	*/
	public long timeInNanoseconds()
	{	return (stopTime - startTime);	}
}
