/****************************************************************************************************
* Project: COMP2080_ASSIGN1_Yogarasa_Ihsaan
* Assignment: ASSIGNMENT #1
* Author(s): Ihsaan Yogarasa
* Student Number: 100947868
* Date: March 22, 2018
* Description: Javadocs LinkedSequence Study Node class
****************************************************************************************************/
package question2;
//this method contains the nodes
public class LinkedSequenceNode<T> {
	private T data;
	private LinkedSequenceNode<T> nextNode;



   public LinkedSequenceNode(T value) {
	   this.data = value;
	   
   }

   public LinkedSequenceNode<T> getNext(){
	
	return nextNode;
}
   
   public void setNext(LinkedSequenceNode<T> element) {
	   
	   this.nextNode = element;
	   
   }

   public T getData() {
	
	return data;
}
}

