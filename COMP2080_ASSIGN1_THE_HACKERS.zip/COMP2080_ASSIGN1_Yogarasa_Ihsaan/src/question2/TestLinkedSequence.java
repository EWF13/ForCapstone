package question2;

public abstract class TestLinkedSequence {

	
	public static void main(String[] args) {
	//executes linked sequence
		static LinkedSequence<T> linksequence;
		
		linksequence = new LinkedSequence();
		
		
	}
	
	

}
