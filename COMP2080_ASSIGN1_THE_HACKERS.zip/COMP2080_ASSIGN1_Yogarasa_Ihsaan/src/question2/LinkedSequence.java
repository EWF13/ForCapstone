/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.Scanner;
import java.io.*;


/****************************************************************************************************
* Project: COMP2080_ASSIGN1_Yogarasa_Ihsaan
* Assignment: ASSIGNMENT #1
* Author(s): Ihsaan Yogarasa
* Student Number: 100947868
* Date: March 22, 2018
* Description: Javadocs LinkedSequence Study
****************************************************************************************************/

public class LinkedSequence<T> implements Cloneable {
 
                
	// some data member to store the objects
	
		private LinkedSequenceNode<T> first = null;
		private LinkedSequenceNode<T> current = null;
		
	/*	public LinkedSequence<?>() {
			
			
			
		}*/
			
			
		
		//method for addAfter
		public void addAfter(LinkedSequenceNode<T> element) {
			
			if (current == null) {
				
				LinkedSequenceNode<T> temp = first;
				while (temp.getNext() != null) {
					
					temp = temp.getNext();
					
				}
				
				temp.setNext(element);
				
			} else {
				
				element.setNext(current.getNext());
				current.setNext(element);
				
			}
			
			current = element;
			
		}
		//method for addAll
		public void addAll(LinkedSequence<T> seq) throws java.lang.NullPointerException {
			
			if (seq == null) throw new java.lang.NullPointerException();
			
			LinkedSequenceNode<T> temp = first;
			while (temp.getNext() != null) temp = temp.getNext();
			
			LinkedSequenceNode<T> temp2 = seq.first;
			while (temp2 != null) {
				
				temp.setNext(temp2);
				temp = temp.getNext();
				temp2 = temp2.getNext();
				
			}
			
			
		}
		//method for advance
		public void advance() throws IllegalStateException {
			
			if (current == null) throw new IllegalStateException();
			
			if (isCurrent()) {
				
				if (current.getNext() != null) {
					
					current = current.getNext();
					
				}
				
			}
			
		}
		//method for cloning
		/*public T clone() {
			
			
			
	}	*/
		//attemped method for concatenation
	/*	public static LinkedSequence<?> concatenation(LinkedSequence<?> s1, LinkedSequence<?> s2) throws java.lang.NullPointerException {
			
			if (s1 == null || s2 == null) throw new java.lang.NullPointerException();
			
			LinkedSequence<?> newList = new LinkedSequence<>();
			
			newList.addAll(s1);
			newList.addAll(s2);;
			
			return newList;
			
		} */
		
		public T getCurrent() throws java.lang.IllegalStateException {
			
			if (current == null) throw new java.lang.IllegalStateException();
			
			return current.getData();
			
		}
		//method for the current node
		public boolean isCurrent() {
			
			if (current != null) return true;
			else return false;
			
		}
		//method for removeCurrent
		public void removeCurrent() throws java.lang.IllegalStateException {
			
			if (current == null) throw new java.lang.IllegalStateException();
			
			if (isCurrent()) {
				
				if (current == first) {
					
					first = first.getNext();
					
				}
				
				LinkedSequenceNode<T> temp = first;
				
				while (temp.getNext() != current) {
					
					temp = temp.getNext();
					
				}
				temp.setNext(current.getNext());
				current = current.getNext();
				
			}
			
		}
		//method for size
		public int size() {
			
			int count = 0;
			
			LinkedSequenceNode<T> temp = first;
			
			while (temp != null) {
				
				count++;
				temp = temp.getNext();
				
			}
			return count;
		}
		// method for start
		public void start() {
			
			current = first;
			
		}
		
	}


