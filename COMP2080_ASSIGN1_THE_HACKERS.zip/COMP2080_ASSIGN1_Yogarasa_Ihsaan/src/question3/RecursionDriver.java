package question3;

import java.util.Scanner;

/****************************************************************************************************
* Project: COMP2080_ASSIGN1_Yogarasa_Ihsaan
* Assignment: ASSIGNMENT #1
* Author(s): Ihsaan Yogarasa
* Student Number: 100947868
* Date: March 22, 2018
* Description: The driver for the Recursion methods
****************************************************************************************************/
public class RecursionDriver {

	// This is the Driver for Recursion
	static RecursionPartIII recur;
	static RecursionLevels recur2;
	 public static void main(String[] args) {
		 
		 // executes the stars question
		 System.out.println("Pattern 3,5 will output");
		  recur = new RecursionPartIII();
		   
		   
		   Scanner user_input = new Scanner(System.in);
			//executes the level question
		   recur2 = new RecursionLevels();
			String repeatedtext;
			System.out.print("Enter text you want repeated: ");
			repeatedtext = user_input.next();
			int levels;
			System.out.println("Enter how many levels you want: ");
			levels = user_input.nextInt();
			System.out.println("Level" + repeatedtext + levels +"will output:");
		  RecursionLevels.level(repeatedtext,levels);
		  
	 }
}
