package question3;
/****************************************************************************************************
* Project: COMP2080_ASSIGN1_Yogarasa_Ihsaan
* Assignment: ASSIGNMENT #1
* Author(s): Ihsaan Yogarasa
* Student Number: 100947868
* Date: March 22, 2018
* Description: The method for Recursion levels
****************************************************************************************************/
import java.util.Scanner;
public class RecursionLevels {
	
	public static void level (String repeatedtext,int levels)
	{
		if (levels > 0)

			for (int i = 1; i <= 9; i++)

				level(repeatedtext + i +".", levels - 1);
		else
			System.out.println(repeatedtext);
	}

}