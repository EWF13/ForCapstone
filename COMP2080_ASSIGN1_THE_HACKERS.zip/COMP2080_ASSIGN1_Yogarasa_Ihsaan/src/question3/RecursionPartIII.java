/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;

/****************************************************************************************************
* Project: COMP2080_ASSIGN1_Yogarasa_Ihsaan
* Assignment: ASSIGNMENT #1
* Author(s): Ihsaan Yogarasa
* Student Number: 100947868
* Date: March 22, 2018
* Description: Recursion methods for recurion stars
****************************************************************************************************/
public class RecursionPartIII {
    
// the following lines of code are for recursion Part 1	  starting with 3 stars to 5, then back to 3 stars
	  private int i,j;
	  
	  // Depending whether i is less than the number it will increase the amount of stars
	  public RecursionPartIII() {
		  for(i=3;i<=5;i++)
		   {
			   for (j=1;j<=i;j++)
				   System.out.print("*");
			   System.out.println();
		   }
		  //Depending whether I is 
		   for(i=3;i<=5;i++)
		   {
			   //Depending whether j is greater than the number it will decrease the amount of stars
			   for (j=7;j>=i;j--)
				   System.out.print("*");
			   System.out.println();
		   }
	   
   
}}